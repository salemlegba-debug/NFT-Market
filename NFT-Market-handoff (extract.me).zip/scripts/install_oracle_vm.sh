#!/usr/bin/env bash
# ==============================================================================
# Script d'installation automatique pour Oracle Cloud Always Free (Ubuntu/Debian)
# ==============================================================================
set -euo pipefail

echo "==> 1. Mise à jour du système..."
sudo apt-get update -y
sudo apt-get install -y python3 python3-pip python3-venv git curl

echo "==> 2. Installation des dépendances Python..."
pip3 install --break-system-packages -r requirements.txt

echo "==> 3. Installation et activation du service systemd..."
sudo cp systemd/nft-market-bot.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable nft-market-bot.service

echo ""
echo "=================================================================="
echo "✅ Installation terminée avec succès !"
echo "1. Assurez-vous que votre fichier .env contient votre DISCORD_TOKEN,"
echo "   SUPABASE_URL et SUPABASE_SERVICE_KEY."
echo "2. Démarrez le bot avec :"
echo "   sudo systemctl start nft-market-bot"
echo "3. Suivez les logs en temps réel avec :"
echo "   journalctl -u nft-market-bot -f"
echo "=================================================================="
