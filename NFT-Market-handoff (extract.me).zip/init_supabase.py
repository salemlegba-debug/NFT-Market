"""Script d'initialisation et de test automatique pour Supabase.

Exécutez ce script pour tester la connexion avec Supabase et vérifier que
les tables nécessaires sont prêtes.
Usage:
    python3 init_supabase.py
"""
import asyncio
import os
import sys
import aiohttp

async def verify_supabase():
    url = os.getenv("SUPABASE_URL", "").strip().rstrip("/")
    key = os.getenv("SUPABASE_SERVICE_KEY", "").strip()

    if not url or not key:
        print("❌ ERREUR: SUPABASE_URL ou SUPABASE_SERVICE_KEY n'est pas configuré dans l'environnement.")
        print("Veuillez renseigner ces variables dans votre fichier .env ou les exporter:")
        print("  export SUPABASE_URL=\"https://votre-projet.supabase.co\"")
        print("  export SUPABASE_SERVICE_KEY=\"votre_cle_service_role\"")
        sys.exit(1)

    print(f"📡 Connexion à Supabase: {url}...")
    headers = {
        "apikey": key,
        "Authorization": f"Bearer {key}",
    }

    tables = ["market_listings", "market_matches", "wallet_sessions", "wallet_associations"]
    async with aiohttp.ClientSession() as session:
        all_ok = True
        for table in tables:
            try:
                async with session.get(f"{url}/rest/v1/{table}?limit=1", headers=headers) as resp:
                    if resp.status == 200:
                        print(f"  ✅ Table '{table}' trouvée et accessible.")
                    elif resp.status == 404:
                        print(f"  ❌ Table '{table}' NON trouvée. Avez-vous exécuté schema.sql dans Supabase SQL Editor ?")
                        all_ok = False
                    else:
                        text = await resp.text()
                        print(f"  ⚠️ Erreur sur '{table}' (status {resp.status}): {text}")
                        all_ok = False
            except Exception as e:
                print(f"  ❌ Erreur de connexion sur '{table}': {e}")
                all_ok = False

        if all_ok:
            print("\n🎉 SUCCÈS: Toutes les tables Supabase sont prêtes et configurées pour NFT Market Bot !")
        else:
            print("\n⚠️ Des tables sont manquantes. Copiez et collez le fichier 'schema.sql' dans l'onglet 'SQL Editor' de votre tableau de bord Supabase.")

if __name__ == "__main__":
    asyncio.run(verify_supabase())
